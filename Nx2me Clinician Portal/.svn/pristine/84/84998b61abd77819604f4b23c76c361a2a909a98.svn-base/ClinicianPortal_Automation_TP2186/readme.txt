Nx2me Clinician Portal - TP2186 - Test Automation - 1.0.0.1 Release
================================================================
May 10, 2021

================================================================

Nx2me Connected.Health v1.0.0 release version
Selenium scripts version 1.0.0.1

================================================================


Contents to verify after extracting "ClinicianPortal_Automation_TP2186.zip"
---------------------------------------------------------------------------

1. A folder named " \ClinicianPortal_Automation_TP2186" should be present in the drive where this "ClinicianPortal_Automation_TP2186.zip" is extracted.
2. Ensure that contents of this folder " ClinicianPortal_Automation_TP2186" should contain the following: 
	a. ‘Configuration’ folder
	b. ClinicianPortalAutomation.exe
	c. Nx2meConnected.Health v1.0.0.exe
	d. DllReg.bat

3. Ensure that contents of this folder "\Configuration" should contain the following:
	a. ‘Driven_Data’ folder
	b. ‘Drivers’ folder
	c. ‘libs’ folder
	d. ‘TestToolData’ folder
	e.  testng.xml 

4. Ensure that the contents of this folder " \Driven_Data " should contain the following:
	a Portal_Drive_Data_1.xlsx

5. Ensure that the contents of this folder " \libs " should contain the ‘tools’ folder. 
	
	Ensure that the contents of this folder " \tools " should contain the following:
		a. AutoItX4Java.jar
		b. jacob.jar
		c. jacob-1.19-x64.dll  
		d. jacob-1.19-x86.dll 

6. Ensure that the contents of this folder " \TestToolData’ " should contain the ‘TP2186’ folder:
	
	Ensure that the contents of this folder " \TP2186’ " should contain the following:
		a. "create_upload_files" folder
		b. "Test_Data" folder

	Ensure that the contents of this folder " \create_upload_files " should contain the following:
		a. CreateFlowsheet_to_generate_alert_0.xml
		b. CreateFlowsheet_to_generate_alert_1.xml
		c. CreateFlowsheet_to_generate_alert_3.xml
		d. CreateFlowsheetFromFilesTask_for_5_fs_with_attachments.xml
		e. CreateFlowsheetFromFilesTask_for_10_fs_Unconfirmed.xml
		f. CreateFlowsheetFromFilesTask_for_40_fs_Confirmed.xml
		g. CreateFlowsheetFromFilesTask_for_50_fs_Confirmed.xml
		h. DashboardPatientSettingsTask1.xml
		i. DashboardPatientSettingsTask2.xml
		j. DashboardPatientSettingsTask3.xml
		k. DbDeleteTask.xml
		l. PdmpPatientSettingsTask1.xml
		m. PdmpPatientSettingsTask2.xml
		n. PdmpPatientSettingsTask3.xml
		o. PdmpTwoWayMessagingTask.xml
		p. Upload_Alert0.cfg
		q. Upload_Alert1.cfg
		r. Upload_Alert3.cfg
		s. Upload_XML_10_Unconfirmed_fs_Files.cfg
		t. Upload_XML_40_Confirmed_fs_Files.cfg
		u. Upload_XML_50_Confirmed_fs_Files.cfg
		v. Upload_XML_with_attachments.cfg
		w. UploadAttachmentTask.xml
		x. UploadFlowsheetTask.xml

	Ensure that the contents of this folder " \Test_Data " should contain the following:
		a. Chrysanthemum.jpg
		b. MyAttachments.txt
		c. PostTxAssessmentSection_alert0.txt
		d. PostTxAssessmentSection_alert1.txt
		e. PostTxAssessmentSection_alert3.txt
		f. PreTxAssessmentSection_alert0.txt
		g. PreTxAssessmentSection_alert1.txt
		h. PreTxAssessmentSection_alert3.txt
		i. PreTxCommentsFile.txt
		j. RxSettingsSection.txt
		k. RxSettingsSection_alert0.txt
		l. RxSettingsSection_alert1.txt
		m. RxSettingsSection_alert3.txt
		n. TxDataSection.txt
		o. TxDataSection_alert0.txt
		p. TxDataSection_alert1.txt
		q. TxDataSection_alert3.txt
